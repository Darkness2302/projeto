<?php
require_once __DIR__ . '/../config/db.php';

class Produto
{
    private PDO $conn;

    public function __construct()
    {
        $this->conn = Database::getConnection();
    }

    /**
     * Lista produtos com nome da categoria, já trazendo os campos
     * usados na tela de Estoque (preço e quantidade).
     */
    public function listarComCategoria(bool $somenteAtivos = false): array
    {
        $sql = "
            SELECT p.id, p.categoria_id, p.nome, p.descricao, p.variacao,
                   p.preco, p.estoque_qtd, p.fornecedor_id,
                   p.ativo, c.nome AS categoria_nome
            FROM produto p
            INNER JOIN categoria1 c ON c.id = p.categoria_id
        ";
        if ($somenteAtivos) {
            $sql .= " WHERE p.ativo = 1 AND c.ativo = 1 ";
        }
        $sql .= " ORDER BY p.id DESC";
        return $this->conn->query($sql)->fetchAll();
    }

    public function buscarPorId(int $id): ?array
    {
        $stmt = $this->conn->prepare("SELECT * FROM produto WHERE id = :id");
        $stmt->execute([':id' => $id]);
        $r = $stmt->fetch();
        return $r ?: null;
    }

    public function inserir(
        int $categoriaId,
        string $nome,
        ?string $descricao,
        ?string $variacao,
        float $preco,
        int $estoqueQtd,
        ?int $fornecedorId
    ): int {
        $stmt = $this->conn->prepare("
            INSERT INTO produto
                (categoria_id, nome, descricao, variacao, preco, estoque_qtd, fornecedor_id, ativo)
            VALUES
                (:categoria_id, :nome, :descricao, :variacao, :preco, :estoque_qtd, :fornecedor_id, 1)
        ");
        $stmt->execute([
            ':categoria_id'  => $categoriaId,
            ':nome'          => $nome,
            ':descricao'     => $descricao,
            ':variacao'      => $variacao,
            ':preco'         => $preco,
            ':estoque_qtd'   => $estoqueQtd,
            ':fornecedor_id' => $fornecedorId
        ]);
        return (int)$this->conn->lastInsertId();
    }

    public function atualizar(
        int $id,
        int $categoriaId,
        string $nome,
        ?string $descricao,
        ?string $variacao,
        float $preco,
        int $estoqueQtd,
        ?int $fornecedorId
    ): void {
        $stmt = $this->conn->prepare("
            UPDATE produto
            SET categoria_id = :categoria_id,
                nome = :nome,
                descricao = :descricao,
                variacao = :variacao,
                preco = :preco,
                estoque_qtd = :estoque_qtd,
                fornecedor_id = :fornecedor_id
            WHERE id = :id
        ");
        $stmt->execute([
            ':id'            => $id,
            ':categoria_id'  => $categoriaId,
            ':nome'          => $nome,
            ':descricao'     => $descricao,
            ':variacao'      => $variacao,
            ':preco'         => $preco,
            ':estoque_qtd'   => $estoqueQtd,
            ':fornecedor_id' => $fornecedorId
        ]);
    }

    public function setAtivo(int $id, bool $ativo): void
    {
        $stmt = $this->conn->prepare("UPDATE produto SET ativo = :ativo WHERE id = :id");
        $stmt->execute([
            ':id' => $id,
            ':ativo' => $ativo ? 1 : 0
        ]);
    }

    public function deletar(int $id): bool
    {
        $stmt = $this->conn->prepare("DELETE FROM produto WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}

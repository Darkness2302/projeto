<?php
$nome   = $_SESSION['nome']   ?? 'Usuário';
$perfil = $_SESSION['perfil'] ?? 'vendedor';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Panela Quente – Menu</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --salmon:   #f3bfac;
      --green:    #a8c288;
      --green-dk: #505c41;
      --teal:     #1f99ac;
      --white:    #ffffff;
      --black:    #111111;
      --gray-ph:  #d9d9d9;
      --page-w:   1400px;
    }
    html { scroll-behavior: smooth; }
    body { font-family:'Inter',sans-serif; background:var(--white); color:var(--black); }

    /* HEADER */
    .page-header { display:flex; align-items:center; gap:28px; padding:18px 24px 12px; max-width:var(--page-w); margin:0 auto; }
    .logo-wrap img { width:120px; height:auto; }
    .header-center { flex:1; text-align:center; }
    .header-title { font-family:'Inter',sans-serif; font-size:2rem; font-weight:500; color:var(--black); }
    .header-logout { font-size:0.9rem; font-weight:400; color:var(--teal); text-decoration:none; display:block; margin-top:4px; opacity:.8; transition:opacity .15s; }
    .header-logout:hover { opacity:1; text-decoration:underline; }

    /* NAV */
    .nav-bar { display:flex; justify-content:center; gap:18px; padding:8px 24px 16px; max-width:var(--page-w); margin:0 auto; }
    .nav-bar a { display:inline-flex; align-items:center; padding:8px 36px; background:linear-gradient(90deg, #a8c288 60%, #505c41 100%); color:var(--black); font-weight:600; font-size:1.25rem; text-decoration:none; border-radius:200px; transition:opacity .15s, transform .15s; }
    .nav-bar a:hover { opacity:.82; transform:translateY(-2px); }
    .nav-bar a.active { background:linear-gradient(90deg, var(--green-dk) 0%, #2d3620 100%); color:#fff; }

    /* HERO */
    .hero { position:relative; width:100%; max-width:var(--page-w); margin:0 auto; height:780px; overflow:hidden; }
    .hero-img { position:absolute; object-fit:cover; }
    .hero-img:nth-child(1) { left:4.6%; top:0; width:54.4%; height:53.6%; }
    .hero-img:nth-child(2) { left:59%; top:5%; width:40.2%; height:43.8%; }
    .hero-img:nth-child(3) { left:50%; top:46%; width:54.9%; height:60.5%; }
    .hero-img:nth-child(4) { left:4.6%; top:50%; width:45.6%; height:54.1%; }

    /* SECTION TITLE */
    .section-title-wrap { max-width:var(--page-w); margin:0 auto; padding:48px 24px 32px; }
    .section-banner { background:var(--salmon); border-radius:5px; padding:12px 28px; font-size:1.35rem; font-weight:400; color:var(--black); display:inline-block; }

    /* PRODUCT GRID */
    .product-grid { display:grid; grid-template-columns:repeat(3, 1fr); gap:28px; max-width:var(--page-w); margin:0 auto; padding:0 24px 60px; }
    .product-card { display:flex; flex-direction:column; }
    .product-card__img { width:100%; aspect-ratio:4/3; border-radius:15px; object-fit:cover; display:block; background:var(--gray-ph); }
    .product-card__placeholder { width:100%; aspect-ratio:4/3; border-radius:15px; background:var(--gray-ph); }
    .product-card__label { background:var(--salmon); border-radius:5px; margin-top:10px; padding:10px 18px; font-size:1.1rem; font-weight:400; color:var(--black); width:fit-content; max-width:100%; }

    /* FOOTER */
    .footer { max-width:var(--page-w); margin:0 auto; padding:48px 24px 80px; display:grid; grid-template-columns:1fr 1fr; gap:60px; align-items:start; }
    .footer__about h3, .footer__contact h3 { font-family:'Inter',sans-serif; font-size:1.6rem; font-weight:600; margin-bottom:22px; }
    .footer__about-box { background:var(--salmon); border-radius:15px; padding:30px 32px; font-size:1.05rem; line-height:1.8; color:#1a1a1a; }
    .footer__about-box p + p { margin-top:14px; }
    .contact-list { display:flex; flex-direction:column; gap:12px; }
    .contact-item { background:var(--salmon); border-radius:5px; padding:10px 18px; display:flex; align-items:center; gap:14px; font-size:1rem; color:var(--black); }
    .contact-item img { width:42px; height:42px; object-fit:contain; flex-shrink:0; }
    .footer-logo-wrap { margin-top:36px; display:flex; justify-content:flex-end; }
    .footer-logo-wrap img { width:200px; height:auto; }

    @media (max-width:900px) {
      .hero { height:400px; }
      .product-grid { grid-template-columns:1fr; gap:20px; }
      .footer { grid-template-columns:1fr; gap:40px; }
      .header-title { font-size:1.25rem; }
    }
    @media (max-width:620px) {
      .product-grid { grid-template-columns:1fr; }
      .hero { height:260px; }
    }
  </style>
</head>
<body>

  <header>
    <div class="page-header">
      <div class="logo-wrap">
        <img src="https://www.figma.com/api/mcp/asset/f35419e2-62a2-4bd1-9243-6cf66c790dc2"
             alt="Restaurante Panela Quente" />
      </div>
      <div class="header-center">
        <h1 class="header-title">Bem-vindo <?= htmlspecialchars($nome) ?> ao Panela Quente</h1>
        <a class="header-logout" href="/projetobernardolohana/index.php?controller=auth&action=logout">
          (<?= htmlspecialchars($perfil) ?>) &mdash; Sair
        </a>
      </div>
    </div>
    <nav class="nav-bar">
      <a href="/projetobernardolohana/index.php?controller=auth&action=dashboard" class="active">Menu</a>
      <a href="/projetobernardolohana/index.php?controller=produto&action=index">Estoque</a>
      <a href="/projetobernardolohana/index.php?controller=venda&action=index">Pedidos</a>
    </nav>
  </header>

  <div class="hero">
    <img class="hero-img" src="https://www.figma.com/api/mcp/asset/1e0f38f3-91d3-4f92-9484-dea5efbd4aa0" alt="Prato" />
    <img class="hero-img" src="https://www.figma.com/api/mcp/asset/1e0f38f3-91d3-4f92-9484-dea5efbd4aa0" alt="Prato" />
    <img class="hero-img" src="https://www.figma.com/api/mcp/asset/1e0f38f3-91d3-4f92-9484-dea5efbd4aa0" alt="Prato" />
    <img class="hero-img" src="https://www.figma.com/api/mcp/asset/1e0f38f3-91d3-4f92-9484-dea5efbd4aa0" alt="Prato" />
  </div>

  <div class="section-title-wrap">
    <span class="section-banner">Refeições mais populares do nosso restaurante.</span>
  </div>
  <div class="product-grid">
    <div class="product-card">
      <img class="product-card__img" src="https://www.figma.com/api/mcp/asset/3c0235fe-4fa2-478a-b4e4-e73ea2e67ae5" alt="Frango com quiabo" />
      <span class="product-card__label">Frango com quiabo</span>
    </div>
    <div class="product-card">
      <img class="product-card__img" src="https://www.figma.com/api/mcp/asset/4bc603c4-e7d6-4980-b8c0-fd24151ec411" alt="Ensopado de carne e batata" />
      <span class="product-card__label">Ensopado de carne e batata</span>
    </div>
    <div class="product-card">
      <img class="product-card__img" src="https://www.figma.com/api/mcp/asset/438a7c92-7833-4055-8abe-c388ddb59e9f" alt="Strogonoff de frango" />
      <span class="product-card__label">Strogonoff de frango</span>
    </div>
  </div>

  <div class="section-title-wrap">
    <span class="section-banner">Bebidas mais pedidas.</span>
  </div>
  <div class="product-grid">
    <div class="product-card"><div class="product-card__placeholder"></div><span class="product-card__label">nome bebida</span></div>
    <div class="product-card"><div class="product-card__placeholder"></div><span class="product-card__label">nome bebida</span></div>
    <div class="product-card"><div class="product-card__placeholder"></div><span class="product-card__label">nome bebida</span></div>
  </div>

  <div class="section-title-wrap">
    <span class="section-banner">Sobremesas famosas.</span>
  </div>
  <div class="product-grid">
    <div class="product-card"><div class="product-card__placeholder"></div><span class="product-card__label">nome doce</span></div>
    <div class="product-card"><div class="product-card__placeholder"></div><span class="product-card__label">nome doce</span></div>
    <div class="product-card"><div class="product-card__placeholder"></div><span class="product-card__label">nome doce</span></div>
  </div>

  <footer class="footer">
    <div class="footer__about">
      <h3>Sobre nosso restaurante:</h3>
      <div class="footer__about-box">
        <p>&nbsp;&nbsp;&nbsp;Somos um restaurante de comida caseira, oferecemos preços acessíveis, ambiente confortável e climatizado, além de contribuirmos para instituições que levam a nutrição e ajudam a sanar a fome de pessoas necessitadas.</p>
        <p>&nbsp;&nbsp;&nbsp;Nosso prazer é levar o melhor da culinária local até sua mesa, fazendo seus almoços em família, e pausas do trabalho, memoráveis e acolhendo ideias que buscam a melhora de nosso estabelecimento e nossos serviços.</p>
        <p>&nbsp;&nbsp;&nbsp;Temos orgulho em servir à você com o melhor da Panela Quente.</p>
      </div>
    </div>
    <div class="footer__contact">
      <h3>Nossos contatos:</h3>
      <div class="contact-list">
        <div class="contact-item">
          <img src="https://www.figma.com/api/mcp/asset/abc518c5-09fa-435e-b3ce-1623cfe144f7" alt="WhatsApp" />
          <span>(21) 99010-5501</span>
        </div>
        <div class="contact-item">
          <img src="https://www.figma.com/api/mcp/asset/3c76640e-8c1a-45d1-9840-9745057db2b4" alt="Instagram" />
          <span>@RestaurantePanelaQuente_oficial</span>
        </div>
        <div class="contact-item">
          <img src="https://www.figma.com/api/mcp/asset/b77036a6-ce01-4049-805e-72972f890757" alt="YouTube" />
          <span>Canal Receitas Práticas do Panela Quente.</span>
        </div>
        <div class="contact-item">
          <img src="https://www.figma.com/api/mcp/asset/f85030ff-cb82-4007-b4b2-cea7d8b96545" alt="Facebook" />
          <span>@RestaurantePanelaQuente_oficial</span>
        </div>
      </div>
      <div class="footer-logo-wrap">
        <img src="https://www.figma.com/api/mcp/asset/f35419e2-62a2-4bd1-9243-6cf66c790dc2" alt="Restaurante Panela Quente" />
      </div>
    </div>
  </footer>

</body>
</html>
